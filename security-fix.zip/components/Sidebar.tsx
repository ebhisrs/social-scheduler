'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { LayoutDashboard, Calendar, PenTool, Clock, Link2, Image, FileText, Bug, LogOut } from 'lucide-react'

const nav = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/calendar', icon: Calendar, label: 'Auto-Calendar' },
  { href: '/composer', icon: PenTool, label: 'Composer' },
  { href: '/articles', icon: FileText, label: 'Articles' },
  { href: '/scheduler', icon: Clock, label: 'Scheduler' },
  { href: '/photos', icon: Image, label: 'Photos' },
  { href: '/connect', icon: Link2, label: 'Connect' },
  { href: '/debug', icon: Bug, label: 'Activity Log', sep: true },
]

export default function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()

  const logout = async () => {
    try { await fetch('/api/login', { method: 'DELETE' }) } catch {}
    router.push('/login')
    router.refresh()
  }

  return (
    <aside style={{ width: 220, minHeight: '100vh', background: 'var(--surface)', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', padding: '24px 12px', flexShrink: 0 }}>
      <div style={{ padding: '0 8px 28px', borderBottom: '1px solid var(--border)', marginBottom: 16 }}>
        <div style={{ fontSize: 18, fontWeight: 800, background: 'linear-gradient(135deg,#6366f1,#8b5cf6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>SocialPilot</div>
        <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 2 }}>AI Social Scheduler</div>
      </div>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2, flex: 1 }}>
        {nav.map(({ href, icon: Icon, label, sep }: any) => {
          const active = pathname === href
          return (
            <Link key={href} href={href} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderRadius: 8, textDecoration: 'none', background: active ? 'rgba(99,102,241,0.15)' : 'transparent', color: active ? '#a5b4fc' : sep ? '#f59e0b' : 'var(--muted)', fontWeight: active ? 600 : 400, fontSize: 13, marginTop: sep ? 8 : 0, borderTop: sep ? '1px solid var(--border)' : 'none', paddingTop: sep ? 17 : 9 }}>
              <Icon size={16} />{label}
            </Link>
          )
        })}
      </nav>
      <button
        onClick={logout}
        style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderRadius: 8, background: 'transparent', color: 'var(--muted)', fontSize: 13, border: '1px solid var(--border)', cursor: 'pointer', marginTop: 16 }}
      >
        <LogOut size={16} /> Logout
      </button>
    </aside>
  )
}
